# About this folder
We put all documentations we found about the original Etherpad together in this folder. Most of this is still valid for the current (node.js based) Etherpad.