#!/bin/bash -ex

rm -fR /etherpad/