#!/bin/bash -ex

chown -R ec2-user:ec2-user /etherpad/
cd /etherpad/
rm -fR node_modules/
cp settings.json.template settings.json
sed -i "s/\"exposeVersion\": false/\"exposeVersion\": true/" settings.json